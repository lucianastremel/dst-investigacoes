/*
 * Proxy opcional (Cloudflare Workers) para o modo "link aberto".
 * O token do GitHub fica guardado aqui, nunca no navegador.
 *
 * Regras:
 *  - GRAVAR (PUT) é liberado para quem tem o link: permite registrar ocorrências.
 *    Para alterar um arquivo existente é preciso o "sha" dele, que só é obtido
 *    por quem tem a chave de leitura — ou pelo próprio autor logo após criar.
 *  - LER (GET: abrir relatório, listar, painel) exige a CHAVE_LEITURA do SESMT.
 *  - Só acessa caminhos dentro de PASTA no repositório configurado.
 *
 * Variáveis do Worker (Settings → Variables):
 *   GITHUB_TOKEN   (secreto) token fine-grained com Contents: Read and write no repositório de dados
 *   CHAVE_LEITURA  (secreto) senha do SESMT para abrir relatórios e usar o painel
 *   OWNER          lucianastremel
 *   REPO           ex.: dsst-investigacoes-dados
 *   BRANCH         ex.: main
 *   PASTA          ex.: dados
 *   ORIGEM         https://lucianastremel.github.io
 */
export default {
  async fetch(req, env) {
    const cors = {
      "Access-Control-Allow-Origin": env.ORIGEM || "*",
      "Access-Control-Allow-Methods": "GET, PUT, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Accept, X-Chave",
      "Access-Control-Max-Age": "86400"
    };
    const resp = (status, obj) => new Response(JSON.stringify(obj), { status, headers: { ...cors, "Content-Type": "application/json" } });

    if (req.method === "OPTIONS") return new Response(null, { headers: cors });
    if (env.ORIGEM && req.headers.get("Origin") && req.headers.get("Origin") !== env.ORIGEM) return resp(403, { message: "Origem não autorizada" });

    const url = new URL(req.url);
    const m = url.pathname.match(/^\/contents\/(.+)$/);
    if (!m) return resp(404, { message: "Rota inválida" });
    const path = m[1].split("/").map(decodeURIComponent).join("/");
    if (path.includes("..") || !(path === env.PASTA || path.startsWith(env.PASTA + "/"))) return resp(403, { message: "Caminho não permitido" });

    const temChave = req.headers.get("X-Chave") && req.headers.get("X-Chave") === env.CHAVE_LEITURA;
    if (req.method === "GET" && !temChave) return resp(401, { message: "Chave de leitura necessária" });
    if (req.method !== "GET" && req.method !== "PUT") return resp(405, { message: "Método não permitido" });

    let body;
    if (req.method === "PUT") {
      const txt = await req.text();
      if (txt.length > 3_000_000) return resp(413, { message: "Arquivo muito grande" });
      let b; try { b = JSON.parse(txt); } catch (e) { return resp(400, { message: "JSON inválido" }); }
      if (!/\.(json|jpe?g|png)$/i.test(path)) return resp(403, { message: "Tipo de arquivo não permitido" });
      body = JSON.stringify({ message: String(b.message || "Registro DSST").slice(0, 200), content: b.content, sha: b.sha, branch: env.BRANCH });
    }

    const gh = `https://api.github.com/repos/${env.OWNER}/${env.REPO}/contents/${path.split("/").map(encodeURIComponent).join("/")}` +
      (req.method === "GET" ? `?ref=${encodeURIComponent(env.BRANCH)}` : "");
    const r = await fetch(gh, {
      method: req.method,
      headers: {
        "Authorization": `Bearer ${env.GITHUB_TOKEN}`,
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "dsst-proxy",
        "Content-Type": "application/json"
      },
      body
    });
    return new Response(r.body, { status: r.status, headers: { ...cors, "Content-Type": "application/json" } });
  }
};
